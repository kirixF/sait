# ER-диаграмма базы данных "LIBRARY"

> **Для ИИ-ассистента:** в этом файле полное описание схемы БД в трёх форматах.
> Используй тот, который удобен для твоей задачи.

---

## 1. DBML (для dbdiagram.io)

```dbml
Table GENRES {
  genre_id   INT         [pk, increment]
  name       VARCHAR(100) [not null]
}

Table AUTHORS {
  author_id  INT          [pk, increment]
  last_name  VARCHAR(100) [not null]
  first_name VARCHAR(100) [not null]
  mid_name   VARCHAR(100)
  country    VARCHAR(100)
}

Table BOOKS {
  book_id    INT          [pk, increment]
  title      VARCHAR(255) [not null]
  genre_id   INT          [not null, ref: > GENRES.genre_id]
  year       INT
  isbn       VARCHAR(20)
}

Table BOOK_AUTHORS {
  book_id    INT [not null, ref: > BOOKS.book_id]
  author_id  INT [not null, ref: > AUTHORS.author_id]
  indexes {
    (book_id, author_id) [pk]
  }
}

Table READERS {
  reader_id    INT          [pk, increment]
  last_name    VARCHAR(100) [not null]
  first_name   VARCHAR(100) [not null]
  mid_name     VARCHAR(100)
  email        VARCHAR(150) [unique]
  phone        VARCHAR(20)
  address      TEXT
  registration DATE         [not null]
}

Table BORROWINGS {
  borrowing_id INT         [pk, increment]
  reader_id    INT         [not null, ref: > READERS.reader_id]
  book_id      INT         [not null, ref: > BOOKS.book_id]
  borrow_date  DATE        [not null]
  return_date  DATE
  status       VARCHAR(20) [not null, default: 'active']
}
```

---

## 2. Mermaid ERD

```mermaid
erDiagram
    GENRES {
        INT     genre_id    PK
        VARCHAR name
    }
    AUTHORS {
        INT     author_id   PK
        VARCHAR last_name
        VARCHAR first_name
        VARCHAR mid_name
        VARCHAR country
    }
    BOOKS {
        INT     book_id     PK
        VARCHAR title
        INT     genre_id    FK
        INT     year
        VARCHAR isbn
    }
    BOOK_AUTHORS {
        INT book_id    FK
        INT author_id  FK
    }
    READERS {
        INT     reader_id    PK
        VARCHAR last_name
        VARCHAR first_name
        VARCHAR mid_name
        VARCHAR email
        VARCHAR phone
        TEXT    address
        DATE    registration
    }
    BORROWINGS {
        INT     borrowing_id PK
        INT     reader_id    FK
        INT     book_id      FK
        DATE    borrow_date
        DATE    return_date
        VARCHAR status
    }

    GENRES      ||--o{ BOOKS        : "1:M"
    BOOKS       ||--o{ BOOK_AUTHORS : "1:M"
    AUTHORS     ||--o{ BOOK_AUTHORS : "1:M"
    READERS     ||--o{ BORROWINGS   : "1:M"
    BOOKS       ||--o{ BORROWINGS   : "1:M"
```

---

## 3. SQL DDL (MySQL / MariaDB)

```sql
CREATE TABLE GENRES (
    genre_id  INT          NOT NULL AUTO_INCREMENT,
    name      VARCHAR(100) NOT NULL,
    PRIMARY KEY (genre_id)
);

CREATE TABLE AUTHORS (
    author_id  INT          NOT NULL AUTO_INCREMENT,
    last_name  VARCHAR(100) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    mid_name   VARCHAR(100),
    country    VARCHAR(100),
    PRIMARY KEY (author_id)
);

CREATE TABLE BOOKS (
    book_id   INT          NOT NULL AUTO_INCREMENT,
    title     VARCHAR(255) NOT NULL,
    genre_id  INT          NOT NULL,
    year      INT,
    isbn      VARCHAR(20),
    PRIMARY KEY (book_id),
    FOREIGN KEY (genre_id) REFERENCES GENRES(genre_id)
);

CREATE TABLE BOOK_AUTHORS (
    book_id   INT NOT NULL,
    author_id INT NOT NULL,
    PRIMARY KEY (book_id, author_id),
    FOREIGN KEY (book_id)   REFERENCES BOOKS(book_id)   ON DELETE CASCADE,
    FOREIGN KEY (author_id) REFERENCES AUTHORS(author_id) ON DELETE CASCADE
);

CREATE TABLE READERS (
    reader_id    INT          NOT NULL AUTO_INCREMENT,
    last_name    VARCHAR(100) NOT NULL,
    first_name   VARCHAR(100) NOT NULL,
    mid_name     VARCHAR(100),
    email        VARCHAR(150) UNIQUE,
    phone        VARCHAR(20),
    address      TEXT,
    registration DATE         NOT NULL DEFAULT (CURRENT_DATE),
    PRIMARY KEY (reader_id)
);

CREATE TABLE BORROWINGS (
    borrowing_id INT         NOT NULL AUTO_INCREMENT,
    reader_id    INT         NOT NULL,
    book_id      INT         NOT NULL,
    borrow_date  DATE        NOT NULL DEFAULT (CURRENT_DATE),
    return_date  DATE,
    status       VARCHAR(20) NOT NULL DEFAULT 'active',
    PRIMARY KEY (borrowing_id),
    FOREIGN KEY (reader_id) REFERENCES READERS(reader_id),
    FOREIGN KEY (book_id)   REFERENCES BOOKS(book_id)
);
```

---

## 4. Текстовое описание связей

| Таблица-родитель | Таблица-потомок | Тип связи | Ключ         |
|------------------|-----------------|-----------|--------------|
| GENRES           | BOOKS           | 1 : M     | genre_id     |
| BOOKS            | BOOK_AUTHORS    | 1 : M     | book_id      |
| AUTHORS          | BOOK_AUTHORS    | 1 : M     | author_id    |
| READERS          | BORROWINGS      | 1 : M     | reader_id    |
| BOOKS            | BORROWINGS      | 1 : M     | book_id      |
| BOOKS ↔ AUTHORS  | (через BOOK_AUTHORS) | **M : N** | book_id + author_id |

### Нормальные формы
- **1НФ:** все атомарные значения, нет повторяющихся групп
- **2НФ:** нет частичных зависимостей (связующая таблица BOOK_AUTHORS с составным PK)
- **3НФ:** нет транзитивных зависимостей (GENRES вынесен отдельно)
