import { db } from '@/lib/db';
import { NextResponse } from 'next/server';

export async function GET() {
  try {
    // Получаем общую статистику
    const [
      totalBooks,
      totalAuthors,
      totalReaders,
      totalBorrowings,
      activeBorrowings,
      overdueBorrowings,
      returnedBorrowings,
      booksWithAuthors,
    ] = await Promise.all([
      db.book.count(),
      db.author.count(),
      db.reader.count(),
      db.borrowing.count(),
      db.borrowing.count({ where: { status: 'active' } }),
      db.borrowing.count({ where: { status: 'overdue' } }),
      db.borrowing.count({ where: { status: 'returned' } }),
      db.book.findMany({
        include: {
          authors: {
            include: {
              author: true,
            },
          },
          genre: true,
          borrowings: true,
        },
      }),
    ]);

    // Топ-3 популярные книги
    const popularBooks = booksWithAuthors
      .map((book) => ({
        id: book.id,
        title: book.title,
        authors: book.authors.map((a) => `${a.author.lastName} ${a.author.firstName}`).join(', '),
        genre: book.genre.name,
        borrowCount: book.borrowings.length,
      }))
      .sort((a, b) => b.borrowCount - a.borrowCount)
      .slice(0, 3);

    // Статистика по жанрам
    const genres = await db.genre.findMany({
      include: {
        books: {
          include: {
            borrowings: true,
          },
        },
      },
    });

    const genreStats = genres.map((genre) => ({
      name: genre.name,
      bookCount: genre.books.length,
      borrowCount: genre.books.reduce((sum, book) => sum + book.borrowings.length, 0),
    }));

    // Последние выдачи
    const recentBorrowings = await db.borrowing.findMany({
      take: 5,
      orderBy: { borrowDate: 'desc' },
      include: {
        book: {
          include: {
            authors: {
              include: {
                author: true,
              },
            },
          },
        },
        reader: true,
      },
    });

    // Просроченные выдачи
    const overdueList = await db.borrowing.findMany({
      where: { status: 'overdue' },
      include: {
        book: {
          include: {
            authors: {
              include: {
                author: true,
              },
            },
          },
        },
        reader: true,
      },
    });

    return NextResponse.json({
      totalBooks,
      totalAuthors,
      totalReaders,
      totalBorrowings,
      activeBorrowings,
      overdueBorrowings,
      returnedBorrowings,
      popularBooks,
      genreStats,
      recentBorrowings: recentBorrowings.map((b) => ({
        id: b.id,
        bookTitle: b.book.title,
        authors: b.book.authors.map((a) => `${a.author.lastName} ${a.author.firstName}`).join(', '),
        readerName: `${b.reader.lastName} ${b.reader.firstName} ${b.reader.middleName || ''}`.trim(),
        borrowDate: b.borrowDate,
        status: b.status,
      })),
      overdueList: overdueList.map((b) => ({
        id: b.id,
        bookTitle: b.book.title,
        authors: b.book.authors.map((a) => `${a.author.lastName} ${a.author.firstName}`).join(', '),
        readerName: `${b.reader.lastName} ${b.reader.firstName} ${b.reader.middleName || ''}`.trim(),
        readerPhone: b.reader.phone,
        borrowDate: b.borrowDate,
        daysOverdue: Math.floor((Date.now() - b.borrowDate.getTime()) / (1000 * 60 * 60 * 24)),
      })),
    });
  } catch (error) {
    console.error('Stats error:', error);
    return NextResponse.json({ error: 'Ошибка при получении статистики' }, { status: 500 });
  }
}
