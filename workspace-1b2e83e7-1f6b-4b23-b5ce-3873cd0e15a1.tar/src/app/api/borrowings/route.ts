import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET - получить все выдачи
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const status = searchParams.get('status');

    const borrowings = await db.borrowing.findMany({
      where: status ? { status } : {},
      include: {
        book: {
          include: {
            authors: {
              include: {
                author: true,
              },
            },
            genre: true,
          },
        },
        reader: true,
      },
      orderBy: { borrowDate: 'desc' },
    });

    const result = borrowings.map((b) => ({
      id: b.id,
      bookId: b.bookId,
      bookTitle: b.book.title,
      bookAuthors: b.book.authors.map((a) => `${a.author.lastName} ${a.author.firstName}`).join(', '),
      genre: b.book.genre.name,
      readerId: b.readerId,
      readerName: `${b.reader.lastName} ${b.reader.firstName}${b.reader.middleName ? ' ' + b.reader.middleName : ''}`,
      readerPhone: b.reader.phone,
      readerEmail: b.reader.email,
      borrowDate: b.borrowDate,
      returnDate: b.returnDate,
      status: b.status,
      daysOnHand: Math.floor((Date.now() - b.borrowDate.getTime()) / (1000 * 60 * 60 * 24)),
    }));

    return NextResponse.json(result);
  } catch (error) {
    console.error('Borrowings GET error:', error);
    return NextResponse.json({ error: 'Ошибка при получении выдач' }, { status: 500 });
  }
}

// POST - создать новую выдачу
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { bookId, readerId } = body;

    // Проверяем, не выдана ли уже книга
    const activeBorrowing = await db.borrowing.findFirst({
      where: {
        bookId: parseInt(bookId),
        status: 'active',
      },
    });

    if (activeBorrowing) {
      return NextResponse.json({ error: 'Книга уже выдана другому читателю' }, { status: 400 });
    }

    const borrowing = await db.borrowing.create({
      data: {
        bookId: parseInt(bookId),
        readerId: parseInt(readerId),
        status: 'active',
      },
      include: {
        book: {
          include: {
            authors: {
              include: {
                author: true,
              },
            },
          },
        },
        reader: true,
      },
    });

    return NextResponse.json({
      id: borrowing.id,
      bookTitle: borrowing.book.title,
      readerName: `${borrowing.reader.lastName} ${borrowing.reader.firstName}`,
      borrowDate: borrowing.borrowDate,
    });
  } catch (error) {
    console.error('Borrowings POST error:', error);
    return NextResponse.json({ error: 'Ошибка при создании выдачи' }, { status: 500 });
  }
}

// PUT - вернуть книгу
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { borrowingId, newStatus } = body;

    const updateData: { returnDate?: Date; status: string } = {
      status: newStatus || 'returned',
    };

    if (newStatus === 'returned') {
      updateData.returnDate = new Date();
    }

    const borrowing = await db.borrowing.update({
      where: { id: parseInt(borrowingId) },
      data: updateData,
      include: {
        book: true,
        reader: true,
      },
    });

    return NextResponse.json({
      id: borrowing.id,
      bookTitle: borrowing.book.title,
      readerName: `${borrowing.reader.lastName} ${borrowing.reader.firstName}`,
      status: borrowing.status,
      returnDate: borrowing.returnDate,
    });
  } catch (error) {
    console.error('Borrowings PUT error:', error);
    return NextResponse.json({ error: 'Ошибка при обновлении выдачи' }, { status: 500 });
  }
}
