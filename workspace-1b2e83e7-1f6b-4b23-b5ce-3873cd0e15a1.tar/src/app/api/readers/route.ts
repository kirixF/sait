import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET - получить всех читателей
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search') || '';

    const readers = await db.reader.findMany({
      where: search
        ? {
            OR: [
              { lastName: { contains: search } },
              { firstName: { contains: search } },
              { email: { contains: search } },
              { phone: { contains: search } },
            ],
          }
        : {},
      include: {
        borrowings: {
          include: {
            book: {
              include: {
                authors: {
                  include: {
                    author: true,
                  },
                },
              },
            },
          },
        },
      },
      orderBy: [{ lastName: 'asc' }, { firstName: 'asc' }],
    });

    const result = readers.map((reader) => ({
      id: reader.id,
      lastName: reader.lastName,
      firstName: reader.firstName,
      middleName: reader.middleName,
      email: reader.email,
      phone: reader.phone,
      registration: reader.registration,
      fullName: `${reader.lastName} ${reader.firstName}${reader.middleName ? ' ' + reader.middleName : ''}`,
      totalBorrowings: reader.borrowings.length,
      activeBorrowings: reader.borrowings.filter((b) => b.status === 'active').length,
      overdueBorrowings: reader.borrowings.filter((b) => b.status === 'overdue').length,
      currentBooks: reader.borrowings
        .filter((b) => b.status === 'active' || b.status === 'overdue')
        .map((b) => ({
          id: b.id,
          bookId: b.book.id,
          title: b.book.title,
          authors: b.book.authors.map((a) => `${a.author.lastName} ${a.author.firstName}`).join(', '),
          borrowDate: b.borrowDate,
          status: b.status,
        })),
    }));

    return NextResponse.json(result);
  } catch (error) {
    console.error('Readers GET error:', error);
    return NextResponse.json({ error: 'Ошибка при получении читателей' }, { status: 500 });
  }
}

// POST - добавить нового читателя
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { lastName, firstName, middleName, email, phone } = body;

    const reader = await db.reader.create({
      data: {
        lastName,
        firstName,
        middleName: middleName || null,
        email: email || null,
        phone: phone || null,
      },
    });

    return NextResponse.json(reader);
  } catch (error) {
    console.error('Readers POST error:', error);
    return NextResponse.json({ error: 'Ошибка при создании читателя' }, { status: 500 });
  }
}
