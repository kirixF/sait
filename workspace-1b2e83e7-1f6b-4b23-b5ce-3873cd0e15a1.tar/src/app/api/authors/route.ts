import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET - получить всех авторов
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search') || '';

    const authors = await db.author.findMany({
      where: search
        ? {
            OR: [
              { lastName: { contains: search } },
              { firstName: { contains: search } },
            ],
          }
        : {},
      include: {
        books: {
          include: {
            book: {
              include: {
                genre: true,
              },
            },
          },
        },
      },
      orderBy: [{ lastName: 'asc' }, { firstName: 'asc' }],
    });

    const result = authors.map((author) => ({
      id: author.id,
      lastName: author.lastName,
      firstName: author.firstName,
      middleName: author.middleName,
      birthYear: author.birthYear,
      country: author.country,
      fullName: `${author.lastName} ${author.firstName}${author.middleName ? ' ' + author.middleName : ''}`,
      bookCount: author.books.length,
      books: author.books.map((b) => ({
        id: b.book.id,
        title: b.book.title,
        genre: b.book.genre.name,
      })),
    }));

    return NextResponse.json(result);
  } catch (error) {
    console.error('Authors GET error:', error);
    return NextResponse.json({ error: 'Ошибка при получении авторов' }, { status: 500 });
  }
}

// POST - добавить нового автора
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { lastName, firstName, middleName, birthYear, country } = body;

    const author = await db.author.create({
      data: {
        lastName,
        firstName,
        middleName: middleName || null,
        birthYear: birthYear ? parseInt(birthYear) : null,
        country: country || null,
      },
    });

    return NextResponse.json(author);
  } catch (error) {
    console.error('Authors POST error:', error);
    return NextResponse.json({ error: 'Ошибка при создании автора' }, { status: 500 });
  }
}
