import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET - получить все книги с авторами и жанрами
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search') || '';
    const genreId = searchParams.get('genreId');

    const books = await db.book.findMany({
      where: {
        AND: [
          search
            ? {
                OR: [
                  { title: { contains: search } },
                  { isbn: { contains: search } },
                ],
              }
            : {},
          genreId ? { genreId: parseInt(genreId) } : {},
        ],
      },
      include: {
        authors: {
          include: {
            author: true,
          },
        },
        genre: true,
        borrowings: {
          where: { status: 'active' },
        },
      },
      orderBy: { title: 'asc' },
    });

    const result = books.map((book) => ({
      id: book.id,
      title: book.title,
      isbn: book.isbn,
      publishYear: book.publishYear,
      genre: book.genre.name,
      genreId: book.genreId,
      authors: book.authors.map((a) => ({
        id: a.author.id,
        name: `${a.author.lastName} ${a.author.firstName}${a.author.middleName ? ' ' + a.author.middleName : ''}`,
      })),
      isAvailable: book.borrowings.length === 0,
    }));

    return NextResponse.json(result);
  } catch (error) {
    console.error('Books GET error:', error);
    return NextResponse.json({ error: 'Ошибка при получении книг' }, { status: 500 });
  }
}

// POST - добавить новую книгу
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { title, isbn, publishYear, genreId, authorIds } = body;

    const book = await db.book.create({
      data: {
        title,
        isbn: isbn || null,
        publishYear: publishYear ? parseInt(publishYear) : null,
        genreId: parseInt(genreId),
        authors: {
          create: authorIds.map((authorId: number) => ({
            authorId,
          })),
        },
      },
      include: {
        authors: {
          include: {
            author: true,
          },
        },
        genre: true,
      },
    });

    return NextResponse.json(book);
  } catch (error) {
    console.error('Books POST error:', error);
    return NextResponse.json({ error: 'Ошибка при создании книги' }, { status: 500 });
  }
}
