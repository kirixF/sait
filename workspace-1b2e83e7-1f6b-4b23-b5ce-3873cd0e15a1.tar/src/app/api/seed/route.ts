import { db } from '@/lib/db';
import { NextResponse } from 'next/server';

export async function POST() {
  try {
    // Очищаем базу данных
    await db.borrowing.deleteMany();
    await db.bookAuthor.deleteMany();
    await db.book.deleteMany();
    await db.author.deleteMany();
    await db.reader.deleteMany();
    await db.genre.deleteMany();

    // 1. Создаем жанры
    const genres = await db.genre.createMany({
      data: [
        { id: 1, name: 'Роман', description: 'Художественные произведения большого объёма' },
        { id: 2, name: 'Детектив', description: 'Произведения о расследовании преступлений' },
        { id: 3, name: 'Фантастика', description: 'Произведения о будущем и технологиях' },
        { id: 4, name: 'Поэзия', description: 'Стихотворные произведения' },
        { id: 5, name: 'История', description: 'Исторические произведения' },
      ],
    });

    // 2. Создаем авторов
    const authors = await db.author.createMany({
      data: [
        { id: 1, lastName: 'Булгаков', firstName: 'Михаил', middleName: 'Афанасьевич', birthYear: 1891, country: 'Россия' },
        { id: 2, lastName: 'Достоевский', firstName: 'Фёдор', middleName: 'Михайлович', birthYear: 1821, country: 'Россия' },
        { id: 3, lastName: 'Кристи', firstName: 'Агата', middleName: null, birthYear: 1890, country: 'Великобритания' },
        { id: 4, lastName: 'Лем', firstName: 'Станислав', middleName: null, birthYear: 1921, country: 'Польша' },
        { id: 5, lastName: 'Пушкин', firstName: 'Александр', middleName: 'Сергеевич', birthYear: 1799, country: 'Россия' },
        { id: 6, lastName: 'Толстой', firstName: 'Лев', middleName: 'Николаевич', birthYear: 1828, country: 'Россия' },
        { id: 7, lastName: 'Херберт', firstName: 'Фрэнк', middleName: null, birthYear: 1920, country: 'США' },
        { id: 8, lastName: 'Есенин', firstName: 'Сергей', middleName: 'Александрович', birthYear: 1895, country: 'Россия' },
        { id: 9, lastName: 'Карамзин', firstName: 'Николай', middleName: 'Михайлович', birthYear: 1766, country: 'Россия' },
      ],
    });

    // 3. Создаем книги
    const books = await db.book.createMany({
      data: [
        { id: 1, title: 'Мастер и Маргарита', isbn: '978-5-17-090431-1', publishYear: 1967, genreId: 1 },
        { id: 2, title: 'Преступление и наказание', isbn: '978-5-17-080261-8', publishYear: 1866, genreId: 1 },
        { id: 3, title: 'Убийство в Восточном экспрессе', isbn: '978-5-17-090123-5', publishYear: 1934, genreId: 2 },
        { id: 4, title: 'Десять негритят', isbn: '978-5-17-090456-4', publishYear: 1939, genreId: 2 },
        { id: 5, title: 'Солярис', isbn: '978-5-17-090789-3', publishYear: 1961, genreId: 3 },
        { id: 6, title: 'Евгений Онегин', isbn: '978-5-17-090321-7', publishYear: 1833, genreId: 4 },
        { id: 7, title: 'Война и мир', isbn: '978-5-17-090654-1', publishYear: 1869, genreId: 1 },
        { id: 8, title: 'Дюна', isbn: '978-5-17-090987-6', publishYear: 1965, genreId: 3 },
        { id: 9, title: 'Стихотворения', isbn: '978-5-17-090234-0', publishYear: 1916, genreId: 4 },
        { id: 10, title: 'История государства Российского', isbn: '978-5-17-090876-2', publishYear: 1818, genreId: 5 },
        { id: 11, title: 'Антология русской классики', isbn: '978-5-17-091234-8', publishYear: 2000, genreId: 1 },
      ],
    });

    // 4. Создаем связи книги-авторы (M:N)
    const bookAuthors = await db.bookAuthor.createMany({
      data: [
        { bookId: 1, authorId: 1 },  // Мастер и Маргарита - Булгаков
        { bookId: 2, authorId: 2 },  // Преступление и наказание - Достоевский
        { bookId: 3, authorId: 3 },  // Убийство в Восточном экспрессе - Кристи
        { bookId: 4, authorId: 3 },  // Десять негритят - Кристи
        { bookId: 5, authorId: 4 },  // Солярис - Лем
        { bookId: 6, authorId: 5 },  // Евгений Онегин - Пушкин
        { bookId: 7, authorId: 6 },  // Война и мир - Толстой
        { bookId: 8, authorId: 7 },  // Дюна - Херберт
        { bookId: 9, authorId: 8 },  // Стихотворения - Есенин
        { bookId: 10, authorId: 9 }, // История государства Российского - Карамзин
        { bookId: 11, authorId: 1 }, // Антология - Булгаков
        { bookId: 11, authorId: 2 }, // Антология - Достоевский (M:N - 2 автора у одной книги)
      ],
    });

    // 5. Создаем читателей
    const readers = await db.reader.createMany({
      data: [
        { id: 1, lastName: 'Иванова', firstName: 'Анна', middleName: 'Сергеевна', email: 'ivanova@mail.ru', phone: '+7-900-100-0001' },
        { id: 2, lastName: 'Петров', firstName: 'Дмитрий', middleName: 'Иванович', email: 'petrov@mail.ru', phone: '+7-900-100-0002' },
        { id: 3, lastName: 'Сидорова', firstName: 'Ольга', middleName: 'Николаевна', email: 'sidorova@mail.ru', phone: '+7-900-100-0003' },
        { id: 4, lastName: 'Козлов', firstName: 'Алексей', middleName: 'Юрьевич', email: 'kozlov@mail.ru', phone: '+7-900-100-0004' },
        { id: 5, lastName: 'Новикова', firstName: 'Екатерина', middleName: 'Петровна', email: 'novikova@mail.ru', phone: '+7-900-100-0005' },
        { id: 6, lastName: 'Морозов', firstName: 'Сергей', middleName: 'Александрович', email: 'morozov@mail.ru', phone: '+7-900-100-0006' },
        { id: 7, lastName: 'Волкова', firstName: 'Татьяна', middleName: 'Дмитриевна', email: 'volkova@mail.ru', phone: '+7-900-100-0007' },
        { id: 8, lastName: 'Лебедева', firstName: 'Наталья', middleName: 'Юрьевна', email: 'lebedeva@mail.ru', phone: '+7-900-100-0008' },
        { id: 9, lastName: 'Орлов', firstName: 'Максим', middleName: 'Олегович', email: 'orlov@mail.ru', phone: '+7-900-100-0009' },
        { id: 10, lastName: 'Соколов', firstName: 'Андрей', middleName: 'Викторович', email: 'sokolov@mail.ru', phone: '+7-900-100-0010' },
      ],
    });

    // 6. Создаем выдачи книг
    const now = new Date();
    const borrowings = await db.borrowing.createMany({
      data: [
        // Активные выдачи
        { bookId: 1, readerId: 1, borrowDate: new Date(now.getTime() - 5 * 24 * 60 * 60 * 1000), status: 'active' },
        { bookId: 3, readerId: 3, borrowDate: new Date(now.getTime() - 10 * 24 * 60 * 60 * 1000), status: 'active' },
        { bookId: 5, readerId: 5, borrowDate: new Date(now.getTime() - 3 * 24 * 60 * 60 * 1000), status: 'active' },
        { bookId: 8, readerId: 8, borrowDate: new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000), status: 'active' },
        { bookId: 6, readerId: 10, borrowDate: new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000), status: 'active' },
        
        // Просроченные выдачи
        { bookId: 2, readerId: 2, borrowDate: new Date(now.getTime() - 55 * 24 * 60 * 60 * 1000), status: 'overdue' },
        { bookId: 4, readerId: 4, borrowDate: new Date(now.getTime() - 50 * 24 * 60 * 60 * 1000), status: 'overdue' },
        { bookId: 7, readerId: 6, borrowDate: new Date(now.getTime() - 45 * 24 * 60 * 60 * 1000), status: 'overdue' },
        
        // Возвращенные книги
        { bookId: 1, readerId: 3, borrowDate: new Date(now.getTime() - 60 * 24 * 60 * 60 * 1000), returnDate: new Date(now.getTime() - 45 * 24 * 60 * 60 * 1000), status: 'returned' },
        { bookId: 5, readerId: 1, borrowDate: new Date(now.getTime() - 40 * 24 * 60 * 60 * 1000), returnDate: new Date(now.getTime() - 25 * 24 * 60 * 60 * 1000), status: 'returned' },
        { bookId: 8, readerId: 5, borrowDate: new Date(now.getTime() - 35 * 24 * 60 * 60 * 1000), returnDate: new Date(now.getTime() - 20 * 24 * 60 * 60 * 1000), status: 'returned' },
        { bookId: 3, readerId: 7, borrowDate: new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000), returnDate: new Date(now.getTime() - 15 * 24 * 60 * 60 * 1000), status: 'returned' },
        { bookId: 6, readerId: 9, borrowDate: new Date(now.getTime() - 25 * 24 * 60 * 60 * 1000), returnDate: new Date(now.getTime() - 10 * 24 * 60 * 60 * 1000), status: 'returned' },
        { bookId: 9, readerId: 2, borrowDate: new Date(now.getTime() - 20 * 24 * 60 * 60 * 1000), returnDate: new Date(now.getTime() - 5 * 24 * 60 * 60 * 1000), status: 'returned' },
      ],
    });

    return NextResponse.json({
      success: true,
      message: 'База данных успешно заполнена тестовыми данными',
      stats: {
        genres: genres.count,
        authors: authors.count,
        books: books.count,
        bookAuthors: bookAuthors.count,
        readers: readers.count,
        borrowings: borrowings.count,
      },
    });
  } catch (error) {
    console.error('Seed error:', error);
    return NextResponse.json({ error: 'Ошибка при заполнении базы данных' }, { status: 500 });
  }
}
