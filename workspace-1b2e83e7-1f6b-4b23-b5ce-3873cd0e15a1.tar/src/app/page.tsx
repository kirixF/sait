'use client'

import { useState, useEffect, useCallback } from 'react'
import { useTheme } from 'next-themes'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Separator } from '@/components/ui/separator'
import { 
  BookOpen, Users, PenTool, BookMarked, AlertTriangle, 
  CheckCircle, Clock, TrendingUp, Search, Plus, 
  RefreshCw, Database, ArrowRightLeft, FileText, ChevronRight,
  Sun, Moon, User, LogOut, Settings, Bell, Bookmark,
  Calendar, Mail, Phone, Shield, Info
} from 'lucide-react'

// Типы данных
interface Stats {
  totalBooks: number
  totalAuthors: number
  totalReaders: number
  totalBorrowings: number
  activeBorrowings: number
  overdueBorrowings: number
  returnedBorrowings: number
  popularBooks: Array<{
    id: number
    title: string
    authors: string
    genre: string
    borrowCount: number
  }>
  genreStats: Array<{
    name: string
    bookCount: number
    borrowCount: number
  }>
  recentBorrowings: Array<{
    id: number
    bookTitle: string
    authors: string
    readerName: string
    borrowDate: string
    status: string
  }>
  overdueList: Array<{
    id: number
    bookTitle: string
    authors: string
    readerName: string
    readerPhone: string
    borrowDate: string
    daysOverdue: number
  }>
}

interface Book {
  id: number
  title: string
  isbn: string | null
  publishYear: number | null
  genre: string
  genreId: number
  authors: Array<{ id: number; name: string }>
  isAvailable: boolean
}

interface Author {
  id: number
  fullName: string
  lastName: string
  firstName: string
  middleName: string | null
  birthYear: number | null
  country: string | null
  bookCount: number
  books: Array<{ id: number; title: string; genre: string }>
}

interface Reader {
  id: number
  fullName: string
  lastName: string
  firstName: string
  middleName: string | null
  email: string | null
  phone: string | null
  registration: string
  totalBorrowings: number
  activeBorrowings: number
  overdueBorrowings: number
  currentBooks: Array<{
    id: number
    bookId: number
    title: string
    authors: string
    borrowDate: string
    status: string
  }>
}

interface Borrowing {
  id: number
  bookId: number
  bookTitle: string
  bookAuthors: string
  genre: string
  readerId: number
  readerName: string
  readerPhone: string | null
  readerEmail: string | null
  borrowDate: string
  returnDate: string | null
  status: string
  daysOnHand: number
}

// Демо пользователь
const DEMO_USER = {
  id: 1,
  name: 'Иванова Анна Сергеевна',
  email: 'ivanova@mail.ru',
  phone: '+7-900-100-0001',
  role: 'Читатель',
  avatar: null,
  registration: '2024-01-15',
  stats: {
    totalBorrowings: 5,
    activeBorrowings: 1,
    returnedBorrowings: 4,
    overdueBorrowings: 0
  },
  currentBooks: [
    { id: 1, title: 'Мастер и Маргарита', authors: 'Булгаков М.А.', borrowDate: '2024-12-20', status: 'active' }
  ],
  history: [
    { id: 1, title: 'Солярис', authors: 'Лем С.', borrowDate: '2024-10-01', returnDate: '2024-10-15', status: 'returned' },
    { id: 2, title: 'Дюна', authors: 'Херберт Ф.', borrowDate: '2024-09-01', returnDate: '2024-09-20', status: 'returned' },
    { id: 3, title: 'Евгений Онегин', authors: 'Пушкин А.С.', borrowDate: '2024-08-01', returnDate: '2024-08-10', status: 'returned' },
    { id: 4, title: 'Война и мир', authors: 'Толстой Л.Н.', borrowDate: '2024-07-01', returnDate: '2024-07-25', status: 'returned' },
  ]
}

// Главный компонент
export default function LibraryDashboard() {
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)
  const [stats, setStats] = useState<Stats | null>(null)
  const [books, setBooks] = useState<Book[]>([])
  const [authors, setAuthors] = useState<Author[]>([])
  const [readers, setReaders] = useState<Reader[]>([])
  const [borrowings, setBorrowings] = useState<Borrowing[]>([])
  const [loading, setLoading] = useState(true)
  const [seeded, setSeeded] = useState(false)
  const [activeTab, setActiveTab] = useState('dashboard')
  
  // Авторизация
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [showProfile, setShowProfile] = useState(false)

  // Состояния для поиска
  const [bookSearch, setBookSearch] = useState('')
  const [authorSearch, setAuthorSearch] = useState('')
  const [readerSearch, setReaderSearch] = useState('')

  // Состояния для диалогов
  const [showAddBook, setShowAddBook] = useState(false)
  const [showAddReader, setShowAddReader] = useState(false)
  const [showBorrow, setShowBorrow] = useState(false)
  const [showER, setShowER] = useState(false)
  const [showNF, setShowNF] = useState(false)

  // Формы
  const [newBook, setNewBook] = useState({ title: '', isbn: '', publishYear: '', genreId: '', authorIds: [] as number[] })
  const [newReader, setNewReader] = useState({ lastName: '', firstName: '', middleName: '', email: '', phone: '' })
  const [borrowForm, setBorrowForm] = useState({ bookId: '', readerId: '' })

  // Fix hydration
  useEffect(() => {
    setMounted(true)
  }, [])

  // Загрузка данных
  const loadStats = useCallback(async () => {
    try {
      const res = await fetch('/api/stats')
      const data = await res.json()
      setStats(data)
    } catch (e) {
      console.error('Error loading stats:', e)
    }
  }, [])

  const loadBooks = useCallback(async (search = '') => {
    try {
      const res = await fetch(`/api/books?search=${encodeURIComponent(search)}`)
      const data = await res.json()
      setBooks(data)
    } catch (e) {
      console.error('Error loading books:', e)
    }
  }, [])

  const loadAuthors = useCallback(async (search = '') => {
    try {
      const res = await fetch(`/api/authors?search=${encodeURIComponent(search)}`)
      const data = await res.json()
      setAuthors(data)
    } catch (e) {
      console.error('Error loading authors:', e)
    }
  }, [])

  const loadReaders = useCallback(async (search = '') => {
    try {
      const res = await fetch(`/api/readers?search=${encodeURIComponent(search)}`)
      const data = await res.json()
      setReaders(data)
    } catch (e) {
      console.error('Error loading readers:', e)
    }
  }, [])

  const loadBorrowings = useCallback(async () => {
    try {
      const res = await fetch('/api/borrowings')
      const data = await res.json()
      setBorrowings(data)
    } catch (e) {
      console.error('Error loading borrowings:', e)
    }
  }, [])

  // Заполнение базы данных
  const handleSeed = async () => {
    try {
      setLoading(true)
      const res = await fetch('/api/seed', { method: 'POST' })
      const data = await res.json()
      if (data.success) {
        setSeeded(true)
        await Promise.all([loadStats(), loadBooks(), loadAuthors(), loadReaders(), loadBorrowings()])
      }
    } catch (e) {
      console.error('Seed error:', e)
    } finally {
      setLoading(false)
    }
  }

  // Добавление книги
  const handleAddBook = async () => {
    try {
      await fetch('/api/books', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newBook),
      })
      setShowAddBook(false)
      setNewBook({ title: '', isbn: '', publishYear: '', genreId: '', authorIds: [] })
      loadBooks()
      loadStats()
    } catch (e) {
      console.error('Add book error:', e)
    }
  }

  // Добавление читателя
  const handleAddReader = async () => {
    try {
      await fetch('/api/readers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newReader),
      })
      setShowAddReader(false)
      setNewReader({ lastName: '', firstName: '', middleName: '', email: '', phone: '' })
      loadReaders()
      loadStats()
    } catch (e) {
      console.error('Add reader error:', e)
    }
  }

  // Выдача книги
  const handleBorrow = async () => {
    try {
      await fetch('/api/borrowings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(borrowForm),
      })
      setShowBorrow(false)
      setBorrowForm({ bookId: '', readerId: '' })
      loadBorrowings()
      loadBooks()
      loadReaders()
      loadStats()
    } catch (e) {
      console.error('Borrow error:', e)
    }
  }

  // Возврат книги
  const handleReturn = async (borrowingId: number, markOverdue = false) => {
    try {
      await fetch('/api/borrowings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          borrowingId, 
          newStatus: markOverdue ? 'overdue' : 'returned' 
        }),
      })
      loadBorrowings()
      loadBooks()
      loadReaders()
      loadStats()
    } catch (e) {
      console.error('Return error:', e)
    }
  }

  // Начальная загрузка
  useEffect(() => {
    const init = async () => {
      setLoading(true)
      await Promise.all([loadStats(), loadBooks(), loadAuthors(), loadReaders(), loadBorrowings()])
      setLoading(false)
    }
    init()
  }, [loadStats, loadBooks, loadAuthors, loadReaders, loadBorrowings])

  // Статус выдачи
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-emerald-500 hover:bg-emerald-600">Активна</Badge>
      case 'overdue':
        return <Badge variant="destructive">Просрочена</Badge>
      case 'returned':
        return <Badge variant="secondary">Возвращена</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  // Форматирование даты
  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('ru-RU', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    })
  }

  if (!mounted || (loading && !stats)) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="w-12 h-12 animate-spin text-emerald-600 mx-auto mb-4" />
          <p className="text-slate-600 dark:text-slate-400 text-lg">Загрузка библиотеки...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 flex flex-col">
      {/* Шапка */}
      <header className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-lg">
                <BookOpen className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-slate-900 dark:text-white">LIBRARY</h1>
                <p className="text-xs text-slate-500 dark:text-slate-400">Библиотечная система • 1НФ/2НФ/3НФ</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {/* Кнопка нормальных форм */}
              <Button variant="outline" size="sm" onClick={() => setShowNF(true)} className="gap-2">
                <Shield className="w-4 h-4" />
                Нормальные формы
              </Button>
              {/* Кнопка ER-диаграммы */}
              <Button variant="outline" size="sm" onClick={() => setShowER(true)} className="gap-2">
                <FileText className="w-4 h-4" />
                ER-диаграмма
              </Button>
              {/* Переключатель темы */}
              <Button
                variant="outline"
                size="icon"
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                className="gap-2"
              >
                {theme === 'dark' ? (
                  <Sun className="w-4 h-4" />
                ) : (
                  <Moon className="w-4 h-4" />
                )}
              </Button>
              {/* Авторизация */}
              {isLoggedIn ? (
                <Button variant="outline" size="sm" onClick={() => setShowProfile(true)} className="gap-2">
                  <Avatar className="w-5 h-5">
                    <AvatarFallback className="text-xs bg-emerald-500 text-white">
                      {DEMO_USER.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  Личный кабинет
                </Button>
              ) : (
                <Button 
                  size="sm" 
                  onClick={() => setIsLoggedIn(true)}
                  className="gap-2 bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700"
                >
                  <User className="w-4 h-4" />
                  Демо-вход
                </Button>
              )}
              <Button 
                size="sm" 
                onClick={handleSeed}
                disabled={loading}
                className="gap-2 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700"
              >
                <Database className="w-4 h-4" />
                {seeded ? 'Обновить' : 'Загрузить данные'}
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Основной контент */}
      <main className="flex-1 max-w-7xl mx-auto px-4 py-6 w-full">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm border border-slate-200 dark:border-slate-700 p-1 rounded-xl shadow-sm">
            <TabsTrigger value="dashboard" className="rounded-lg data-[state=active]:bg-emerald-500 data-[state=active]:text-white gap-2">
              <TrendingUp className="w-4 h-4" />
              Дашборд
            </TabsTrigger>
            <TabsTrigger value="books" className="rounded-lg data-[state=active]:bg-emerald-500 data-[state=active]:text-white gap-2">
              <BookMarked className="w-4 h-4" />
              Книги
            </TabsTrigger>
            <TabsTrigger value="authors" className="rounded-lg data-[state=active]:bg-emerald-500 data-[state=active]:text-white gap-2">
              <PenTool className="w-4 h-4" />
              Авторы
            </TabsTrigger>
            <TabsTrigger value="readers" className="rounded-lg data-[state=active]:bg-emerald-500 data-[state=active]:text-white gap-2">
              <Users className="w-4 h-4" />
              Читатели
            </TabsTrigger>
            <TabsTrigger value="borrowings" className="rounded-lg data-[state=active]:bg-emerald-500 data-[state=active]:text-white gap-2">
              <ArrowRightLeft className="w-4 h-4" />
              Выдачи
            </TabsTrigger>
          </TabsList>

          {/* Дашборд */}
          <TabsContent value="dashboard" className="space-y-6">
            {!seeded && stats?.totalBooks === 0 ? (
              <Alert className="bg-amber-50 dark:bg-amber-950/50 border-amber-200 dark:border-amber-800">
                <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                <AlertDescription className="text-amber-800 dark:text-amber-200">
                  База данных пуста. Нажмите &quot;Загрузить данные&quot; для заполнения тестовыми данными.
                </AlertDescription>
              </Alert>
            ) : null}

            {/* Статистика */}
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
              <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white border-0 shadow-lg shadow-blue-500/20">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <BookMarked className="w-8 h-8 opacity-80" />
                    <div>
                      <p className="text-2xl font-bold">{stats?.totalBooks || 0}</p>
                      <p className="text-sm opacity-80">Книг</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-gradient-to-br from-amber-500 to-orange-500 text-white border-0 shadow-lg shadow-amber-500/20">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <PenTool className="w-8 h-8 opacity-80" />
                    <div>
                      <p className="text-2xl font-bold">{stats?.totalAuthors || 0}</p>
                      <p className="text-sm opacity-80">Авторов</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-gradient-to-br from-pink-500 to-rose-500 text-white border-0 shadow-lg shadow-pink-500/20">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <Users className="w-8 h-8 opacity-80" />
                    <div>
                      <p className="text-2xl font-bold">{stats?.totalReaders || 0}</p>
                      <p className="text-sm opacity-80">Читателей</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-gradient-to-br from-violet-500 to-purple-600 text-white border-0 shadow-lg shadow-violet-500/20">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <ArrowRightLeft className="w-8 h-8 opacity-80" />
                    <div>
                      <p className="text-2xl font-bold">{stats?.totalBorrowings || 0}</p>
                      <p className="text-sm opacity-80">Выдач</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-gradient-to-br from-emerald-500 to-teal-600 text-white border-0 shadow-lg shadow-emerald-500/20">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-8 h-8 opacity-80" />
                    <div>
                      <p className="text-2xl font-bold">{stats?.activeBorrowings || 0}</p>
                      <p className="text-sm opacity-80">Активных</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-gradient-to-br from-red-500 to-rose-600 text-white border-0 shadow-lg shadow-red-500/20">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <AlertTriangle className="w-8 h-8 opacity-80" />
                    <div>
                      <p className="text-2xl font-bold">{stats?.overdueBorrowings || 0}</p>
                      <p className="text-sm opacity-80">Просрочено</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-gradient-to-br from-slate-500 to-slate-600 text-white border-0 shadow-lg shadow-slate-500/20">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <Clock className="w-8 h-8 opacity-80" />
                    <div>
                      <p className="text-2xl font-bold">{stats?.returnedBorrowings || 0}</p>
                      <p className="text-sm opacity-80">Возвращено</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Графики и таблицы */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Популярные книги */}
              <Card className="shadow-lg border-slate-200 dark:border-slate-800">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-emerald-600" />
                    Топ-3 популярные книги
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {stats?.popularBooks.map((book, i) => (
                      <div key={book.id} className="flex items-center gap-3 p-3 rounded-lg bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-sm ${i === 0 ? 'bg-amber-500' : i === 1 ? 'bg-slate-400' : 'bg-amber-700'}`}>
                          {i + 1}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-slate-900 dark:text-white truncate">{book.title}</p>
                          <p className="text-sm text-slate-500 dark:text-slate-400">{book.authors}</p>
                        </div>
                        <Badge variant="outline" className="shrink-0">{book.borrowCount} выдач</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Статистика по жанрам */}
              <Card className="shadow-lg border-slate-200 dark:border-slate-800">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BookOpen className="w-5 h-5 text-blue-600" />
                    Статистика по жанрам
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {stats?.genreStats.map((genre) => (
                      <div key={genre.name} className="flex items-center gap-3">
                        <div className="flex-1">
                          <div className="flex justify-between text-sm mb-1">
                            <span className="font-medium text-slate-700 dark:text-slate-300">{genre.name}</span>
                            <span className="text-slate-500 dark:text-slate-400">{genre.bookCount} книг</span>
                          </div>
                          <div className="h-2 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full transition-all"
                              style={{ width: `${Math.min(100, (genre.borrowCount / Math.max(1, stats?.totalBorrowings || 1)) * 100)}%` }}
                            />
                          </div>
                        </div>
                        <Badge variant="secondary" className="shrink-0">{genre.borrowCount} выдач</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Последние выдачи */}
              <Card className="shadow-lg border-slate-200 dark:border-slate-800">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="w-5 h-5 text-violet-600" />
                    Последние выдачи
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-64">
                    <div className="space-y-2">
                      {stats?.recentBorrowings.map((b) => (
                        <div key={b.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-slate-900 dark:text-white truncate text-sm">{b.bookTitle}</p>
                            <p className="text-xs text-slate-500 dark:text-slate-400">{b.readerName}</p>
                          </div>
                          {getStatusBadge(b.status)}
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              {/* Просроченные выдачи */}
              <Card className="shadow-lg border-slate-200 dark:border-slate-800">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-red-600 dark:text-red-400">
                    <AlertTriangle className="w-5 h-5" />
                    Просроченные выдачи
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {stats?.overdueList.length === 0 ? (
                    <p className="text-slate-500 dark:text-slate-400 text-center py-8">Нет просроченных выдач</p>
                  ) : (
                    <ScrollArea className="h-64">
                      <div className="space-y-2">
                        {stats?.overdueList.map((b) => (
                          <div key={b.id} className="flex items-center gap-3 p-2 rounded-lg bg-red-50 dark:bg-red-950/50 border border-red-100 dark:border-red-900">
                            <div className="flex-1 min-w-0">
                              <p className="font-medium text-slate-900 dark:text-white truncate text-sm">{b.bookTitle}</p>
                              <p className="text-xs text-slate-500 dark:text-slate-400">{b.readerName} • {b.readerPhone}</p>
                            </div>
                            <Badge variant="destructive" className="shrink-0">{b.daysOverdue} дней</Badge>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Книги */}
          <TabsContent value="books" className="space-y-4">
            <div className="flex items-center justify-between gap-4">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input 
                  placeholder="Поиск по названию или ISBN..."
                  className="pl-10 bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700"
                  value={bookSearch}
                  onChange={(e) => {
                    setBookSearch(e.target.value)
                    loadBooks(e.target.value)
                  }}
                />
              </div>
              <Dialog open={showAddBook} onOpenChange={setShowAddBook}>
                <DialogTrigger asChild>
                  <Button className="gap-2 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700">
                    <Plus className="w-4 h-4" />
                    Добавить книгу
                  </Button>
                </DialogTrigger>
                <DialogContent className="dark:bg-slate-900">
                  <DialogHeader>
                    <DialogTitle>Добавить новую книгу</DialogTitle>
                    <DialogDescription>Заполните информацию о книге</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label>Название</Label>
                      <Input value={newBook.title} onChange={(e) => setNewBook({...newBook, title: e.target.value})} />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>ISBN</Label>
                        <Input value={newBook.isbn} onChange={(e) => setNewBook({...newBook, isbn: e.target.value})} />
                      </div>
                      <div className="space-y-2">
                        <Label>Год публикации</Label>
                        <Input type="number" value={newBook.publishYear} onChange={(e) => setNewBook({...newBook, publishYear: e.target.value})} />
                      </div>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setShowAddBook(false)}>Отмена</Button>
                    <Button onClick={handleAddBook}>Добавить</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
            <Card className="shadow-lg border-slate-200 dark:border-slate-800">
              <CardContent className="p-0">
                <ScrollArea className="h-[calc(100vh-320px)]">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-slate-50 dark:bg-slate-800">
                        <TableHead className="font-semibold">Книга</TableHead>
                        <TableHead className="font-semibold">Авторы</TableHead>
                        <TableHead className="font-semibold">Жанр</TableHead>
                        <TableHead className="font-semibold">Год</TableHead>
                        <TableHead className="font-semibold">ISBN</TableHead>
                        <TableHead className="font-semibold">Статус</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {books.map((book) => (
                        <TableRow key={book.id} className="hover:bg-slate-50 dark:hover:bg-slate-800">
                          <TableCell className="font-medium text-slate-900 dark:text-white">{book.title}</TableCell>
                          <TableCell>
                            <div className="flex flex-wrap gap-1">
                              {book.authors.map((a) => (
                                <Badge key={a.id} variant="outline" className="text-xs">{a.name}</Badge>
                              ))}
                            </div>
                          </TableCell>
                          <TableCell><Badge variant="secondary">{book.genre}</Badge></TableCell>
                          <TableCell className="text-slate-600 dark:text-slate-400">{book.publishYear || '—'}</TableCell>
                          <TableCell className="text-slate-500 dark:text-slate-400 text-sm">{book.isbn || '—'}</TableCell>
                          <TableCell>
                            {book.isAvailable ? (
                              <Badge className="bg-emerald-500 hover:bg-emerald-600">Доступна</Badge>
                            ) : (
                              <Badge variant="destructive">Выдана</Badge>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Авторы */}
          <TabsContent value="authors" className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input 
                  placeholder="Поиск по фамилии или имени..."
                  className="pl-10 bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700"
                  value={authorSearch}
                  onChange={(e) => {
                    setAuthorSearch(e.target.value)
                    loadAuthors(e.target.value)
                  }}
                />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {authors.map((author) => (
                <Card key={author.id} className="shadow-md border-slate-200 dark:border-slate-800 hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-2">
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg text-slate-900 dark:text-white">{author.fullName}</CardTitle>
                        <CardDescription className="dark:text-slate-400">{author.country || 'Неизвестно'} • {author.birthYear || '—'} г.р.</CardDescription>
                      </div>
                      <Badge variant="outline">{author.bookCount} книг</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-1">
                      {author.books.slice(0, 3).map((book) => (
                        <div key={book.id} className="flex items-center gap-2 text-sm">
                          <ChevronRight className="w-3 h-3 text-slate-400" />
                          <span className="truncate text-slate-700 dark:text-slate-300">{book.title}</span>
                          <Badge variant="secondary" className="text-xs ml-auto">{book.genre}</Badge>
                        </div>
                      ))}
                      {author.books.length > 3 && (
                        <p className="text-xs text-slate-500 dark:text-slate-400 text-center pt-2">и ещё {author.books.length - 3} книг</p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Читатели */}
          <TabsContent value="readers" className="space-y-4">
            <div className="flex items-center justify-between gap-4">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input 
                  placeholder="Поиск по ФИО, email или телефону..."
                  className="pl-10 bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700"
                  value={readerSearch}
                  onChange={(e) => {
                    setReaderSearch(e.target.value)
                    loadReaders(e.target.value)
                  }}
                />
              </div>
              <Dialog open={showAddReader} onOpenChange={setShowAddReader}>
                <DialogTrigger asChild>
                  <Button className="gap-2 bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600">
                    <Plus className="w-4 h-4" />
                    Добавить читателя
                  </Button>
                </DialogTrigger>
                <DialogContent className="dark:bg-slate-900">
                  <DialogHeader>
                    <DialogTitle>Добавить нового читателя</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="grid grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label>Фамилия</Label>
                        <Input value={newReader.lastName} onChange={(e) => setNewReader({...newReader, lastName: e.target.value})} />
                      </div>
                      <div className="space-y-2">
                        <Label>Имя</Label>
                        <Input value={newReader.firstName} onChange={(e) => setNewReader({...newReader, firstName: e.target.value})} />
                      </div>
                      <div className="space-y-2">
                        <Label>Отчество</Label>
                        <Input value={newReader.middleName} onChange={(e) => setNewReader({...newReader, middleName: e.target.value})} />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Email</Label>
                        <Input type="email" value={newReader.email} onChange={(e) => setNewReader({...newReader, email: e.target.value})} />
                      </div>
                      <div className="space-y-2">
                        <Label>Телефон</Label>
                        <Input value={newReader.phone} onChange={(e) => setNewReader({...newReader, phone: e.target.value})} />
                      </div>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setShowAddReader(false)}>Отмена</Button>
                    <Button onClick={handleAddReader}>Добавить</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
            <Card className="shadow-lg border-slate-200 dark:border-slate-800">
              <CardContent className="p-0">
                <ScrollArea className="h-[calc(100vh-320px)]">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-slate-50 dark:bg-slate-800">
                        <TableHead className="font-semibold">Читатель</TableHead>
                        <TableHead className="font-semibold">Контакты</TableHead>
                        <TableHead className="font-semibold">Выдач</TableHead>
                        <TableHead className="font-semibold">На руках</TableHead>
                        <TableHead className="font-semibold">Просрочено</TableHead>
                        <TableHead className="font-semibold">Книги</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {readers.map((reader) => (
                        <TableRow key={reader.id} className="hover:bg-slate-50 dark:hover:bg-slate-800">
                          <TableCell className="font-medium text-slate-900 dark:text-white">{reader.fullName}</TableCell>
                          <TableCell>
                            <div className="text-sm">
                              <p className="dark:text-slate-300">{reader.email || '—'}</p>
                              <p className="text-slate-500 dark:text-slate-400">{reader.phone || '—'}</p>
                            </div>
                          </TableCell>
                          <TableCell className="dark:text-slate-300">{reader.totalBorrowings}</TableCell>
                          <TableCell>
                            <Badge className="bg-emerald-500">{reader.activeBorrowings}</Badge>
                          </TableCell>
                          <TableCell>
                            {reader.overdueBorrowings > 0 ? (
                              <Badge variant="destructive">{reader.overdueBorrowings}</Badge>
                            ) : (
                              <span className="text-slate-400">0</span>
                            )}
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-wrap gap-1">
                              {reader.currentBooks.slice(0, 2).map((b) => (
                                <Badge key={b.id} variant={b.status === 'overdue' ? 'destructive' : 'outline'} className="text-xs">
                                  {b.title}
                                </Badge>
                              ))}
                              {reader.currentBooks.length > 2 && (
                                <Badge variant="secondary" className="text-xs">+{reader.currentBooks.length - 2}</Badge>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Выдачи */}
          <TabsContent value="borrowings" className="space-y-4">
            <div className="flex items-center justify-between gap-4">
              <Dialog open={showBorrow} onOpenChange={setShowBorrow}>
                <DialogTrigger asChild>
                  <Button className="gap-2 bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700">
                    <Plus className="w-4 h-4" />
                    Выдать книгу
                  </Button>
                </DialogTrigger>
                <DialogContent className="dark:bg-slate-900">
                  <DialogHeader>
                    <DialogTitle>Выдать книгу</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label>Книга</Label>
                      <Select value={borrowForm.bookId} onValueChange={(v) => setBorrowForm({...borrowForm, bookId: v})}>
                        <SelectTrigger className="dark:bg-slate-800">
                          <SelectValue placeholder="Выберите книгу" />
                        </SelectTrigger>
                        <SelectContent className="dark:bg-slate-800">
                          {books.filter(b => b.isAvailable).map((b) => (
                            <SelectItem key={b.id} value={b.id.toString()}>{b.title}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Читатель</Label>
                      <Select value={borrowForm.readerId} onValueChange={(v) => setBorrowForm({...borrowForm, readerId: v})}>
                        <SelectTrigger className="dark:bg-slate-800">
                          <SelectValue placeholder="Выберите читателя" />
                        </SelectTrigger>
                        <SelectContent className="dark:bg-slate-800">
                          {readers.map((r) => (
                            <SelectItem key={r.id} value={r.id.toString()}>{r.fullName}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setShowBorrow(false)}>Отмена</Button>
                    <Button onClick={handleBorrow}>Выдать</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
            <Card className="shadow-lg border-slate-200 dark:border-slate-800">
              <CardContent className="p-0">
                <ScrollArea className="h-[calc(100vh-320px)]">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-slate-50 dark:bg-slate-800">
                        <TableHead className="font-semibold">Книга</TableHead>
                        <TableHead className="font-semibold">Читатель</TableHead>
                        <TableHead className="font-semibold">Дата выдачи</TableHead>
                        <TableHead className="font-semibold">Дней</TableHead>
                        <TableHead className="font-semibold">Статус</TableHead>
                        <TableHead className="font-semibold">Действия</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {borrowings.map((b) => (
                        <TableRow key={b.id} className="hover:bg-slate-50 dark:hover:bg-slate-800">
                          <TableCell>
                            <div>
                              <p className="font-medium text-slate-900 dark:text-white">{b.bookTitle}</p>
                              <p className="text-xs text-slate-500 dark:text-slate-400">{b.bookAuthors}</p>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div>
                              <p className="font-medium text-slate-900 dark:text-white">{b.readerName}</p>
                              <p className="text-xs text-slate-500 dark:text-slate-400">{b.readerPhone}</p>
                            </div>
                          </TableCell>
                          <TableCell className="dark:text-slate-300">{formatDate(b.borrowDate)}</TableCell>
                          <TableCell>
                            <Badge variant={b.daysOnHand > 30 ? 'destructive' : 'outline'}>{b.daysOnHand}</Badge>
                          </TableCell>
                          <TableCell>{getStatusBadge(b.status)}</TableCell>
                          <TableCell>
                            {b.status !== 'returned' && (
                              <div className="flex gap-2">
                                <Button size="sm" variant="outline" onClick={() => handleReturn(b.id)}>
                                  <CheckCircle className="w-4 h-4 text-emerald-600" />
                                </Button>
                                {b.status !== 'overdue' && (
                                  <Button size="sm" variant="outline" onClick={() => handleReturn(b.id, true)}>
                                    <AlertTriangle className="w-4 h-4 text-red-600" />
                                  </Button>
                                )}
                              </div>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* Футер */}
      <footer className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 py-4 mt-auto">
        <div className="max-w-7xl mx-auto px-4 text-center text-sm text-slate-500 dark:text-slate-400">
          <p>База данных LIBRARY • 6 таблиц • M:N связь • 1НФ/2НФ/3НФ нормализация</p>
        </div>
      </footer>

      {/* Диалог ER-диаграммы */}
      <Dialog open={showER} onOpenChange={setShowER}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-auto dark:bg-slate-900">
          <DialogHeader>
            <DialogTitle>ER-диаграмма базы данных LIBRARY</DialogTitle>
            <DialogDescription>
              6 таблиц • Связь M:N между Книгами и Авторами • 1НФ/2НФ/3НФ
            </DialogDescription>
          </DialogHeader>
          <div className="relative w-full">
            <img 
              src="/er-diagram.png" 
              alt="ER Diagram" 
              className="w-full h-auto rounded-lg"
            />
          </div>
        </DialogContent>
      </Dialog>

      {/* Диалог нормальных форм */}
      <Dialog open={showNF} onOpenChange={setShowNF}>
        <DialogContent className="max-w-2xl dark:bg-slate-900">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-emerald-600" />
              Нормальные формы базы данных
            </DialogTitle>
            <DialogDescription>
              База данных LIBRARY соответствует всем трём нормальным формам
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {/* 1НФ */}
            <Card className="border-emerald-200 dark:border-emerald-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-600" />
                  1НФ - Первая нормальная форма
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-600 dark:text-slate-400 mb-2">
                  Все атрибуты атомарны (неделимы):
                </p>
                <ul className="text-sm space-y-1 text-slate-500 dark:text-slate-400">
                  <li>• ФИО авторов разбито: last_name, first_name, middle_name</li>
                  <li>• ФИО читателей разбито: last_name, first_name, middle_name</li>
                  <li>• Каждая ячейка содержит одно значение</li>
                  <li>• Нет повторяющихся групп</li>
                </ul>
              </CardContent>
            </Card>

            {/* 2НФ */}
            <Card className="border-blue-200 dark:border-blue-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-blue-600" />
                  2НФ - Вторая нормальная форма
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-600 dark:text-slate-400 mb-2">
                  Все неключевые атрибуты зависят от полного первичного ключа:
                </p>
                <ul className="text-sm space-y-1 text-slate-500 dark:text-slate-400">
                  <li>• В BOOK_AUTHORS составной ключ (book_id, author_id) - нет других атрибутов</li>
                  <li>• Все атрибуты BOOKS зависят от book_id</li>
                  <li>• Все атрибуты AUTHORS зависят от author_id</li>
                </ul>
              </CardContent>
            </Card>

            {/* 3НФ */}
            <Card className="border-violet-200 dark:border-violet-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-violet-600" />
                  3НФ - Третья нормальная форма
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-600 dark:text-slate-400 mb-2">
                  Нет транзитивных зависимостей:
                </p>
                <ul className="text-sm space-y-1 text-slate-500 dark:text-slate-400">
                  <li>• genre_name вынесен в таблицу GENRES (не дублируется)</li>
                  <li>• country хранится в AUTHORS (не дублируется в BOOKS)</li>
                  <li>• Все неключевые атрибуты зависят только от PK</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </DialogContent>
      </Dialog>

      {/* Диалог личного кабинета */}
      <Dialog open={showProfile} onOpenChange={setShowProfile}>
        <DialogContent className="max-w-2xl dark:bg-slate-900">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <User className="w-5 h-5 text-violet-600" />
              Личный кабинет
            </DialogTitle>
            <DialogDescription>
              Демо-версия авторизации
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {/* Профиль */}
            <div className="flex items-center gap-4 p-4 rounded-lg bg-slate-50 dark:bg-slate-800">
              <Avatar className="w-16 h-16">
                <AvatarFallback className="text-xl bg-gradient-to-br from-violet-500 to-purple-600 text-white">
                  {DEMO_USER.name.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <h3 className="font-bold text-lg text-slate-900 dark:text-white">{DEMO_USER.name}</h3>
                <div className="flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400">
                  <Badge variant="outline">{DEMO_USER.role}</Badge>
                </div>
              </div>
              <Button variant="outline" size="sm" onClick={() => { setIsLoggedIn(false); setShowProfile(false); }} className="gap-2">
                <LogOut className="w-4 h-4" />
                Выйти
              </Button>
            </div>

            {/* Контакты */}
            <Card className="border-slate-200 dark:border-slate-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Settings className="w-4 h-4" />
                  Контактная информация
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <Mail className="w-4 h-4 text-slate-400" />
                  <span className="text-slate-600 dark:text-slate-400">{DEMO_USER.email}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Phone className="w-4 h-4 text-slate-400" />
                  <span className="text-slate-600 dark:text-slate-400">{DEMO_USER.phone}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Calendar className="w-4 h-4 text-slate-400" />
                  <span className="text-slate-600 dark:text-slate-400">Регистрация: {formatDate(DEMO_USER.registration)}</span>
                </div>
              </CardContent>
            </Card>

            {/* Статистика */}
            <div className="grid grid-cols-4 gap-2">
              <Card className="text-center p-3 border-slate-200 dark:border-slate-800">
                <p className="text-2xl font-bold text-emerald-600">{DEMO_USER.stats.totalBorrowings}</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">Всего выдач</p>
              </Card>
              <Card className="text-center p-3 border-slate-200 dark:border-slate-800">
                <p className="text-2xl font-bold text-blue-600">{DEMO_USER.stats.activeBorrowings}</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">На руках</p>
              </Card>
              <Card className="text-center p-3 border-slate-200 dark:border-slate-800">
                <p className="text-2xl font-bold text-slate-600 dark:text-slate-400">{DEMO_USER.stats.returnedBorrowings}</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">Возвращено</p>
              </Card>
              <Card className="text-center p-3 border-slate-200 dark:border-slate-800">
                <p className="text-2xl font-bold text-red-600">{DEMO_USER.stats.overdueBorrowings}</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">Просрочено</p>
              </Card>
            </div>

            {/* Текущие книги */}
            <Card className="border-slate-200 dark:border-slate-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Bookmark className="w-4 h-4" />
                  Книги на руках
                </CardTitle>
              </CardHeader>
              <CardContent>
                {DEMO_USER.currentBooks.length === 0 ? (
                  <p className="text-sm text-slate-500 dark:text-slate-400">Нет книг на руках</p>
                ) : (
                  <div className="space-y-2">
                    {DEMO_USER.currentBooks.map((book) => (
                      <div key={book.id} className="flex items-center gap-3 p-2 rounded-lg bg-emerald-50 dark:bg-emerald-950/50">
                        <BookOpen className="w-5 h-5 text-emerald-600" />
                        <div className="flex-1">
                          <p className="font-medium text-sm text-slate-900 dark:text-white">{book.title}</p>
                          <p className="text-xs text-slate-500 dark:text-slate-400">{book.authors} • с {formatDate(book.borrowDate)}</p>
                        </div>
                        <Badge className="bg-emerald-500">Активна</Badge>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* История */}
            <Card className="border-slate-200 dark:border-slate-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  История выдач
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-32">
                  <div className="space-y-2">
                    {DEMO_USER.history.map((book) => (
                      <div key={book.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800">
                        <CheckCircle className="w-4 h-4 text-slate-400" />
                        <div className="flex-1">
                          <p className="font-medium text-sm text-slate-700 dark:text-slate-300">{book.title}</p>
                          <p className="text-xs text-slate-500 dark:text-slate-400">
                            {formatDate(book.borrowDate)} - {formatDate(book.returnDate)}
                          </p>
                        </div>
                        <Badge variant="secondary" className="text-xs">Возвращена</Badge>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
