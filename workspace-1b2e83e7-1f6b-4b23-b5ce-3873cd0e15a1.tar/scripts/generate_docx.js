const { 
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, ImageRun,
  Header, Footer, AlignmentType, LevelFormat, HeadingLevel, BorderStyle, 
  WidthType, ShadingType, VerticalAlign, PageNumber, PageBreak
} = require('docx');
const fs = require('fs');

// Цвета
const colors = {
  primary: '1a1f16',
  accent: '6b7280',
  tableBg: 'f8faf7',
  headerBg: 'e8f5e9',
  pk: 'dc2626',
  fk: '2563eb'
};

// Границы таблицы
const tableBorder = { style: BorderStyle.SINGLE, size: 1, color: 'CCCCCC' };
const cellBorders = { top: tableBorder, bottom: tableBorder, left: tableBorder, right: tableBorder };

// Читаем изображение ER-диаграммы
const erDiagramImage = fs.readFileSync('/home/z/my-project/public/er-diagram.png');

const doc = new Document({
  styles: {
    default: { document: { run: { font: 'Times New Roman', size: 24 } } },
    paragraphStyles: [
      { id: 'Title', name: 'Title', basedOn: 'Normal',
        run: { size: 48, bold: true, color: colors.primary, font: 'Times New Roman' },
        paragraph: { spacing: { before: 0, after: 200 }, alignment: AlignmentType.CENTER } },
      { id: 'Heading1', name: 'Heading 1', basedOn: 'Normal', next: 'Normal', quickFormat: true,
        run: { size: 32, bold: true, color: colors.primary, font: 'Times New Roman' },
        paragraph: { spacing: { before: 300, after: 200 }, outlineLevel: 0 } },
      { id: 'Heading2', name: 'Heading 2', basedOn: 'Normal', next: 'Normal', quickFormat: true,
        run: { size: 28, bold: true, color: colors.primary, font: 'Times New Roman' },
        paragraph: { spacing: { before: 200, after: 150 }, outlineLevel: 1 } },
      { id: 'Heading3', name: 'Heading 3', basedOn: 'Normal', next: 'Normal', quickFormat: true,
        run: { size: 24, bold: true, color: colors.primary, font: 'Times New Roman' },
        paragraph: { spacing: { before: 150, after: 100 }, outlineLevel: 2 } },
      { id: 'Code', name: 'Code', basedOn: 'Normal',
        run: { size: 20, font: 'Courier New', color: '1e293b' },
        paragraph: { spacing: { before: 100, after: 100 } } }
    ]
  },
  numbering: {
    config: [
      { reference: 'bullet-list',
        levels: [{ level: 0, format: LevelFormat.BULLET, text: '•', alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: 'numbered-list-1',
        levels: [{ level: 0, format: LevelFormat.DECIMAL, text: '%1.', alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: 'numbered-list-2',
        levels: [{ level: 0, format: LevelFormat.DECIMAL, text: '%1.', alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: 'numbered-list-3',
        levels: [{ level: 0, format: LevelFormat.DECIMAL, text: '%1.', alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] }
    ]
  },
  sections: [{
    properties: {
      page: { margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } }
    },
    headers: {
      default: new Header({ children: [new Paragraph({ 
        alignment: AlignmentType.RIGHT,
        children: [new TextRun({ text: 'LIBRARY - Техническая документация', size: 20, color: colors.accent })]
      })] })
    },
    footers: {
      default: new Footer({ children: [new Paragraph({ 
        alignment: AlignmentType.CENTER,
        children: [
          new TextRun({ text: 'Страница ', size: 20 }), 
          new TextRun({ children: [PageNumber.CURRENT], size: 20 }), 
          new TextRun({ text: ' из ', size: 20 }), 
          new TextRun({ children: [PageNumber.TOTAL_PAGES], size: 20 })
        ]
      })] })
    },
    children: [
      // Титульная страница
      new Paragraph({ spacing: { before: 2000 } }),
      new Paragraph({ heading: HeadingLevel.TITLE, children: [new TextRun('ТЕХНИЧЕСКАЯ ДОКУМЕНТАЦИЯ')] }),
      new Paragraph({ 
        alignment: AlignmentType.CENTER, 
        spacing: { after: 400 },
        children: [new TextRun({ text: 'База данных "LIBRARY"', size: 36, bold: true })]
      }),
      new Paragraph({ 
        alignment: AlignmentType.CENTER, 
        spacing: { after: 200 },
        children: [new TextRun({ text: 'Библиотечная информационная система', size: 28, color: colors.accent })]
      }),
      new Paragraph({ 
        alignment: AlignmentType.CENTER,
        children: [new TextRun({ text: 'Версия 1.0', size: 22, color: colors.accent })]
      }),
      
      new Paragraph({ children: [new PageBreak()] }),
      
      // 1. Введение
      new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun('1. ВВЕДЕНИЕ')] }),
      new Paragraph({ 
        spacing: { after: 200, line: 360 },
        children: [new TextRun({ text: 'Документация описывает структуру реляционной базы данных "LIBRARY" для автоматизации работы библиотеки. База данных разработана с соблюдением трёх нормальных форм (1НФ, 2НФ, 3НФ) и содержит 6 таблиц с одной связью "многие-ко-многим" (M:N).', size: 24 })]
      }),
      
      new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun('1.1. Цели и задачи')] }),
      new Paragraph({ numbering: { reference: 'bullet-list', level: 0 }, children: [new TextRun({ text: 'Хранение информации о книгах, авторах и читателях', size: 24 })] }),
      new Paragraph({ numbering: { reference: 'bullet-list', level: 0 }, children: [new TextRun({ text: 'Учёт выдачи и возврата книг', size: 24 })] }),
      new Paragraph({ numbering: { reference: 'bullet-list', level: 0 }, children: [new TextRun({ text: 'Поддержка связи "многие-ко-многим" между книгами и авторами', size: 24 })] }),
      new Paragraph({ numbering: { reference: 'bullet-list', level: 0 }, children: [new TextRun({ text: 'Обеспечение целостности и непротиворечивости данных', size: 24 })] }),
      
      // 2. Нормализация
      new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun('2. НОРМАЛИЗАЦИЯ БАЗЫ ДАННЫХ')] }),
      
      new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun('2.1. Первая нормальная форма (1НФ)')] }),
      new Paragraph({ 
        spacing: { after: 100, line: 360 },
        children: [new TextRun({ text: 'Все атрибуты отношений являются атомарными (неделимыми):', size: 24 })]
      }),
      new Paragraph({ numbering: { reference: 'numbered-list-1', level: 0 }, children: [new TextRun({ text: 'ФИО авторов разбито на отдельные поля: last_name, first_name, middle_name', size: 24 })] }),
      new Paragraph({ numbering: { reference: 'numbered-list-1', level: 0 }, children: [new TextRun({ text: 'ФИО читателей разбито на отдельные поля: last_name, first_name, middle_name', size: 24 })] }),
      new Paragraph({ numbering: { reference: 'numbered-list-1', level: 0 }, children: [new TextRun({ text: 'Поле middle_name допускает NULL (отчество не обязательно)', size: 24 })] }),
      new Paragraph({ numbering: { reference: 'numbered-list-1', level: 0 }, children: [new TextRun({ text: 'Каждая ячейка содержит одно значение одного типа', size: 24 })] }),
      new Paragraph({ numbering: { reference: 'numbered-list-1', level: 0 }, children: [new TextRun({ text: 'Связь M:N реализована через связующую таблицу BOOK_AUTHORS', size: 24 })] }),
      
      new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun('2.2. Вторая нормальная форма (2НФ)')] }),
      new Paragraph({ 
        spacing: { after: 100, line: 360 },
        children: [new TextRun({ text: 'Все неключевые атрибуты функционально полно зависят от первичного ключа:', size: 24 })]
      }),
      new Paragraph({ numbering: { reference: 'numbered-list-2', level: 0 }, children: [new TextRun({ text: 'В BOOK_AUTHORS составной PK (book_id, author_id) — нет других атрибутов', size: 24 })] }),
      new Paragraph({ numbering: { reference: 'numbered-list-2', level: 0 }, children: [new TextRun({ text: 'Все атрибуты BOOKS зависят от book_id целиком', size: 24 })] }),
      new Paragraph({ numbering: { reference: 'numbered-list-2', level: 0 }, children: [new TextRun({ text: 'Все атрибуты AUTHORS зависят от author_id целиком', size: 24 })] }),
      
      new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun('2.3. Третья нормальная форма (3НФ)')] }),
      new Paragraph({ 
        spacing: { after: 100, line: 360 },
        children: [new TextRun({ text: 'Отсутствуют транзитивные зависимости:', size: 24 })]
      }),
      new Paragraph({ numbering: { reference: 'numbered-list-3', level: 0 }, children: [new TextRun({ text: 'Название жанра вынесено в таблицу GENRES (не дублируется)', size: 24 })] }),
      new Paragraph({ numbering: { reference: 'numbered-list-3', level: 0 }, children: [new TextRun({ text: 'Страна автора хранится только в таблице AUTHORS', size: 24 })] }),
      new Paragraph({ numbering: { reference: 'numbered-list-3', level: 0 }, children: [new TextRun({ text: 'Все неключевые атрибуты зависят только от первичного ключа', size: 24 })] }),
      
      // 3. Структура таблиц
      new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun('3. СТРУКТУРА ТАБЛИЦ')] }),
      
      // GENRES
      new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun('3.1. Таблица GENRES (Жанры)')] }),
      new Paragraph({ 
        spacing: { after: 100, line: 360 },
        children: [new TextRun({ text: 'Справочник жанров литературных произведений.', size: 24 })]
      }),
      new Table({
        columnWidths: [2500, 2000, 2000, 2860],
        margins: { top: 100, bottom: 100, left: 150, right: 150 },
        rows: [
          new TableRow({
            tableHeader: true,
            children: [
              new TableCell({ borders: cellBorders, width: { size: 2500, type: WidthType.DXA }, shading: { fill: colors.headerBg, type: ShadingType.CLEAR }, verticalAlign: VerticalAlign.CENTER, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Поле', bold: true, size: 22 })] })] }),
              new TableCell({ borders: cellBorders, width: { size: 2000, type: WidthType.DXA }, shading: { fill: colors.headerBg, type: ShadingType.CLEAR }, verticalAlign: VerticalAlign.CENTER, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Тип', bold: true, size: 22 })] })] }),
              new TableCell({ borders: cellBorders, width: { size: 2000, type: WidthType.DXA }, shading: { fill: colors.headerBg, type: ShadingType.CLEAR }, verticalAlign: VerticalAlign.CENTER, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Ограничения', bold: true, size: 22 })] })] }),
              new TableCell({ borders: cellBorders, width: { size: 2860, type: WidthType.DXA }, shading: { fill: colors.headerBg, type: ShadingType.CLEAR }, verticalAlign: VerticalAlign.CENTER, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Описание', bold: true, size: 22 })] })] })
            ]
          }),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, width: { size: 2500, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun({ text: 'genre_id', size: 22, color: colors.pk, bold: true })] })] }),
            new TableCell({ borders: cellBorders, width: { size: 2000, type: WidthType.DXA }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'INT', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, width: { size: 2000, type: WidthType.DXA }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'PK, AUTO', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, width: { size: 2860, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun({ text: 'Идентификатор', size: 22 })] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, width: { size: 2500, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun({ text: 'name', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, width: { size: 2000, type: WidthType.DXA }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'VARCHAR(100)', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, width: { size: 2000, type: WidthType.DXA }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'NOT NULL, UNIQUE', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, width: { size: 2860, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun({ text: 'Название жанра', size: 22 })] })] })
          ]})
        ]
      }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 50, after: 200 }, children: [new TextRun({ text: 'Таблица 1 — Структура таблицы GENRES', size: 20, italics: true, color: colors.accent })] }),
      
      // AUTHORS
      new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun('3.2. Таблица AUTHORS (Авторы)')] }),
      new Paragraph({ 
        spacing: { after: 100, line: 360 },
        children: [new TextRun({ text: 'Справочник авторов книг. ФИО разбито на отдельные поля (1НФ).', size: 24 })]
      }),
      new Table({
        columnWidths: [2500, 2000, 2000, 2860],
        margins: { top: 100, bottom: 100, left: 150, right: 150 },
        rows: [
          new TableRow({
            tableHeader: true,
            children: [
              new TableCell({ borders: cellBorders, width: { size: 2500, type: WidthType.DXA }, shading: { fill: colors.headerBg, type: ShadingType.CLEAR }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Поле', bold: true, size: 22 })] })] }),
              new TableCell({ borders: cellBorders, width: { size: 2000, type: WidthType.DXA }, shading: { fill: colors.headerBg, type: ShadingType.CLEAR }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Тип', bold: true, size: 22 })] })] }),
              new TableCell({ borders: cellBorders, width: { size: 2000, type: WidthType.DXA }, shading: { fill: colors.headerBg, type: ShadingType.CLEAR }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Ограничения', bold: true, size: 22 })] })] }),
              new TableCell({ borders: cellBorders, width: { size: 2860, type: WidthType.DXA }, shading: { fill: colors.headerBg, type: ShadingType.CLEAR }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Описание', bold: true, size: 22 })] })] })
            ]
          }),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'author_id', size: 22, color: colors.pk, bold: true })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'INT', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'PK, AUTO', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'Идентификатор', size: 22 })] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'last_name', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'VARCHAR(100)', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'NOT NULL', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'Фамилия', size: 22 })] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'first_name', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'VARCHAR(100)', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'NOT NULL', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'Имя', size: 22 })] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'mid_name', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'VARCHAR(100)', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'NULL', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'Отчество', size: 22 })] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'country', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'VARCHAR(100)', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'NULL', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'Страна', size: 22 })] })] })
          ]})
        ]
      }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 50, after: 200 }, children: [new TextRun({ text: 'Таблица 2 — Структура таблицы AUTHORS', size: 20, italics: true, color: colors.accent })] }),
      
      // BOOKS
      new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun('3.3. Таблица BOOKS (Книги)')] }),
      new Paragraph({ 
        spacing: { after: 100, line: 360 },
        children: [new TextRun({ text: 'Каталог книг библиотеки. Связь с авторами через таблицу BOOK_AUTHORS (M:N).', size: 24 })]
      }),
      new Table({
        columnWidths: [2500, 2000, 2000, 2860],
        margins: { top: 100, bottom: 100, left: 150, right: 150 },
        rows: [
          new TableRow({
            tableHeader: true,
            children: [
              new TableCell({ borders: cellBorders, shading: { fill: colors.headerBg, type: ShadingType.CLEAR }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Поле', bold: true, size: 22 })] })] }),
              new TableCell({ borders: cellBorders, shading: { fill: colors.headerBg, type: ShadingType.CLEAR }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Тип', bold: true, size: 22 })] })] }),
              new TableCell({ borders: cellBorders, shading: { fill: colors.headerBg, type: ShadingType.CLEAR }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Ограничения', bold: true, size: 22 })] })] }),
              new TableCell({ borders: cellBorders, shading: { fill: colors.headerBg, type: ShadingType.CLEAR }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Описание', bold: true, size: 22 })] })] })
            ]
          }),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'book_id', size: 22, color: colors.pk, bold: true })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'INT', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'PK, AUTO', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'Идентификатор', size: 22 })] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'title', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'VARCHAR(255)', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'NOT NULL', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'Название книги', size: 22 })] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'genre_id', size: 22, color: colors.fk, bold: true })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'INT', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'FK → GENRES', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'Жанр книги', size: 22 })] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'year', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'INT', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'NULL', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'Год публикации', size: 22 })] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'isbn', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'VARCHAR(20)', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'UNIQUE', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'ISBN книги', size: 22 })] })] })
          ]})
        ]
      }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 50, after: 200 }, children: [new TextRun({ text: 'Таблица 3 — Структура таблицы BOOKS', size: 20, italics: true, color: colors.accent })] }),
      
      // BOOK_AUTHORS
      new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun('3.4. Таблица BOOK_AUTHORS (Связь M:N)')] }),
      new Paragraph({ 
        spacing: { after: 100, line: 360 },
        children: [new TextRun({ text: 'Связующая таблица для реализации связи "многие-ко-многим" между книгами и авторами. Одна книга может иметь нескольких авторов, один автор может написать несколько книг.', size: 24 })]
      }),
      new Table({
        columnWidths: [2500, 2000, 2000, 2860],
        margins: { top: 100, bottom: 100, left: 150, right: 150 },
        rows: [
          new TableRow({
            tableHeader: true,
            children: [
              new TableCell({ borders: cellBorders, shading: { fill: colors.headerBg, type: ShadingType.CLEAR }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Поле', bold: true, size: 22 })] })] }),
              new TableCell({ borders: cellBorders, shading: { fill: colors.headerBg, type: ShadingType.CLEAR }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Тип', bold: true, size: 22 })] })] }),
              new TableCell({ borders: cellBorders, shading: { fill: colors.headerBg, type: ShadingType.CLEAR }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Ограничения', bold: true, size: 22 })] })] }),
              new TableCell({ borders: cellBorders, shading: { fill: colors.headerBg, type: ShadingType.CLEAR }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Описание', bold: true, size: 22 })] })] })
            ]
          }),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'book_id', size: 22, color: colors.pk, bold: true })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'INT', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'PK, FK → BOOKS', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'Ссылка на книгу', size: 22 })] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'author_id', size: 22, color: colors.pk, bold: true })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'INT', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'PK, FK → AUTHORS', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'Ссылка на автора', size: 22 })] })] })
          ]})
        ]
      }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 50, after: 200 }, children: [new TextRun({ text: 'Таблица 4 — Структура таблицы BOOK_AUTHORS', size: 20, italics: true, color: colors.accent })] }),
      
      // READERS
      new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun('3.5. Таблица READERS (Читатели)')] }),
      new Paragraph({ 
        spacing: { after: 100, line: 360 },
        children: [new TextRun({ text: 'Справочник зарегистрированных читателей библиотеки. ФИО разбито на отдельные поля (1НФ).', size: 24 })]
      }),
      new Table({
        columnWidths: [2500, 2000, 2000, 2860],
        margins: { top: 100, bottom: 100, left: 150, right: 150 },
        rows: [
          new TableRow({
            tableHeader: true,
            children: [
              new TableCell({ borders: cellBorders, shading: { fill: colors.headerBg, type: ShadingType.CLEAR }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Поле', bold: true, size: 22 })] })] }),
              new TableCell({ borders: cellBorders, shading: { fill: colors.headerBg, type: ShadingType.CLEAR }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Тип', bold: true, size: 22 })] })] }),
              new TableCell({ borders: cellBorders, shading: { fill: colors.headerBg, type: ShadingType.CLEAR }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Ограничения', bold: true, size: 22 })] })] }),
              new TableCell({ borders: cellBorders, shading: { fill: colors.headerBg, type: ShadingType.CLEAR }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Описание', bold: true, size: 22 })] })] })
            ]
          }),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'reader_id', size: 22, color: colors.pk, bold: true })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'INT', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'PK, AUTO', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'Идентификатор', size: 22 })] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'last_name', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'VARCHAR(100)', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'NOT NULL', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'Фамилия', size: 22 })] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'first_name', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'VARCHAR(100)', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'NOT NULL', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'Имя', size: 22 })] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'mid_name', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'VARCHAR(100)', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'NULL', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'Отчество', size: 22 })] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'email', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'VARCHAR(150)', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'UNIQUE', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'Email', size: 22 })] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'phone', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'VARCHAR(20)', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'UNIQUE', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'Телефон', size: 22 })] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'registration', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'DATE', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'NOT NULL, DEFAULT', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'Дата регистрации', size: 22 })] })] })
          ]})
        ]
      }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 50, after: 200 }, children: [new TextRun({ text: 'Таблица 5 — Структура таблицы READERS', size: 20, italics: true, color: colors.accent })] }),
      
      // BORROWINGS
      new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun('3.6. Таблица BORROWINGS (Выдача книг)')] }),
      new Paragraph({ 
        spacing: { after: 100, line: 360 },
        children: [new TextRun({ text: 'Транзакционная таблица для учёта выдачи книг читателям.', size: 24 })]
      }),
      new Table({
        columnWidths: [2500, 2000, 2000, 2860],
        margins: { top: 100, bottom: 100, left: 150, right: 150 },
        rows: [
          new TableRow({
            tableHeader: true,
            children: [
              new TableCell({ borders: cellBorders, shading: { fill: colors.headerBg, type: ShadingType.CLEAR }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Поле', bold: true, size: 22 })] })] }),
              new TableCell({ borders: cellBorders, shading: { fill: colors.headerBg, type: ShadingType.CLEAR }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Тип', bold: true, size: 22 })] })] }),
              new TableCell({ borders: cellBorders, shading: { fill: colors.headerBg, type: ShadingType.CLEAR }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Ограничения', bold: true, size: 22 })] })] }),
              new TableCell({ borders: cellBorders, shading: { fill: colors.headerBg, type: ShadingType.CLEAR }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Описание', bold: true, size: 22 })] })] })
            ]
          }),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'borrowing_id', size: 22, color: colors.pk, bold: true })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'INT', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'PK, AUTO', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'Идентификатор', size: 22 })] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'reader_id', size: 22, color: colors.fk, bold: true })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'INT', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'FK → READERS', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'Читатель', size: 22 })] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'book_id', size: 22, color: colors.fk, bold: true })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'INT', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'FK → BOOKS', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'Книга', size: 22 })] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'borrow_date', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'DATE', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'NOT NULL, DEFAULT', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'Дата выдачи', size: 22 })] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'return_date', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'DATE', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'NULL', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'Дата возврата', size: 22 })] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'status', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'VARCHAR(20)', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'CHECK', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'active/returned/overdue', size: 22 })] })] })
          ]})
        ]
      }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 50, after: 200 }, children: [new TextRun({ text: 'Таблица 6 — Структура таблицы BORROWINGS', size: 20, italics: true, color: colors.accent })] }),
      
      // 4. Связи
      new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun('4. СВЯЗИ МЕЖДУ ТАБЛИЦАМИ')] }),
      new Table({
        columnWidths: [2200, 1800, 1500, 2000, 1860],
        margins: { top: 100, bottom: 100, left: 150, right: 150 },
        rows: [
          new TableRow({
            tableHeader: true,
            children: [
              new TableCell({ borders: cellBorders, shading: { fill: colors.headerBg, type: ShadingType.CLEAR }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Родитель', bold: true, size: 22 })] })] }),
              new TableCell({ borders: cellBorders, shading: { fill: colors.headerBg, type: ShadingType.CLEAR }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Потомок', bold: true, size: 22 })] })] }),
              new TableCell({ borders: cellBorders, shading: { fill: colors.headerBg, type: ShadingType.CLEAR }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Тип', bold: true, size: 22 })] })] }),
              new TableCell({ borders: cellBorders, shading: { fill: colors.headerBg, type: ShadingType.CLEAR }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Ключ', bold: true, size: 22 })] })] }),
              new TableCell({ borders: cellBorders, shading: { fill: colors.headerBg, type: ShadingType.CLEAR }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Описание', bold: true, size: 22 })] })] })
            ]
          }),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'GENRES', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'BOOKS', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: '1 : M', size: 22, bold: true })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'genre_id', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'Один жанр — много книг', size: 22 })] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'BOOKS', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'BOOK_AUTHORS', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: '1 : M', size: 22, bold: true })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'book_id', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'Связующая таблица', size: 22 })] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'AUTHORS', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'BOOK_AUTHORS', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: '1 : M', size: 22, bold: true })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'author_id', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'Связующая таблица', size: 22 })] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'BOOKS ↔ AUTHORS', size: 22, bold: true })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: '—', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'M : N', size: 22, bold: true, color: colors.pk })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: '—', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'Через BOOK_AUTHORS', size: 22 })] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'READERS', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'BORROWINGS', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: '1 : M', size: 22, bold: true })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'reader_id', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'Один читатель — много выдач', size: 22 })] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'BOOKS', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'BORROWINGS', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: '1 : M', size: 22, bold: true })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'book_id', size: 22 })] })] }),
            new TableCell({ borders: cellBorders, children: [new Paragraph({ children: [new TextRun({ text: 'Одна книга — много выдач', size: 22 })] })] })
          ]})
        ]
      }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 50, after: 200 }, children: [new TextRun({ text: 'Таблица 7 — Связи между таблицами', size: 20, italics: true, color: colors.accent })] }),
      
      // 5. ER-диаграмма
      new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun('5. ER-ДИАГРАММА')] }),
      new Paragraph({ 
        spacing: { after: 200, line: 360 },
        children: [new TextRun({ text: 'Диаграмма "сущность-связь" (Entity-Relationship) с использованием нотации Crow\'s Foot (лапки) для отображения кардинальности связей:', size: 24 })]
      }),
      new Paragraph({
        alignment: AlignmentType.CENTER,
        children: [new ImageRun({
          type: 'png',
          data: erDiagramImage,
          transformation: { width: 580, height: 460 },
          altText: { title: 'ER-диаграмма', description: 'ER-диаграмма базы данных LIBRARY', name: 'ER Diagram' }
        })]
      }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 50, after: 200 }, children: [new TextRun({ text: 'Рисунок 1 — ER-диаграмма базы данных LIBRARY', size: 20, italics: true, color: colors.accent })] }),
      
      new Paragraph({ children: [new PageBreak()] }),
      
      // 6. SQL DDL
      new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun('6. SQL DDL (MySQL / MariaDB)')] }),
      new Paragraph({ 
        spacing: { after: 100, line: 360 },
        children: [new TextRun({ text: 'Скрипт создания таблиц базы данных:', size: 24 })]
      }),
      
      // SQL код
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: 'CREATE DATABASE library CHARACTER SET utf8mb4;', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: 'USE library;', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', children: [new TextRun({ text: '', size: 20 })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '-- 1. Справочник жанров', size: 20, font: 'Courier New', italics: true })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: 'CREATE TABLE GENRES (', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    genre_id  INT          NOT NULL AUTO_INCREMENT,', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    name      VARCHAR(100) NOT NULL,', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    PRIMARY KEY (genre_id)', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: ');', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', children: [new TextRun({ text: '', size: 20 })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '-- 2. Авторы', size: 20, font: 'Courier New', italics: true })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: 'CREATE TABLE AUTHORS (', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    author_id  INT          NOT NULL AUTO_INCREMENT,', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    last_name  VARCHAR(100) NOT NULL,', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    first_name VARCHAR(100) NOT NULL,', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    mid_name   VARCHAR(100),', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    country    VARCHAR(100),', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    PRIMARY KEY (author_id)', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: ');', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', children: [new TextRun({ text: '', size: 20 })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '-- 3. Книги', size: 20, font: 'Courier New', italics: true })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: 'CREATE TABLE BOOKS (', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    book_id   INT          NOT NULL AUTO_INCREMENT,', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    title     VARCHAR(255) NOT NULL,', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    genre_id  INT          NOT NULL,', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    year      INT,', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    isbn      VARCHAR(20),', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    PRIMARY KEY (book_id),', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    FOREIGN KEY (genre_id) REFERENCES GENRES(genre_id)', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: ');', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', children: [new TextRun({ text: '', size: 20 })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '-- 4. Связующая таблица M:N', size: 20, font: 'Courier New', italics: true })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: 'CREATE TABLE BOOK_AUTHORS (', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    book_id   INT NOT NULL,', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    author_id INT NOT NULL,', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    PRIMARY KEY (book_id, author_id),', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    FOREIGN KEY (book_id) REFERENCES BOOKS(book_id) ON DELETE CASCADE,', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    FOREIGN KEY (author_id) REFERENCES AUTHORS(author_id) ON DELETE CASCADE', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: ');', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', children: [new TextRun({ text: '', size: 20 })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '-- 5. Читатели', size: 20, font: 'Courier New', italics: true })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: 'CREATE TABLE READERS (', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    reader_id    INT          NOT NULL AUTO_INCREMENT,', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    last_name    VARCHAR(100) NOT NULL,', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    first_name   VARCHAR(100) NOT NULL,', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    mid_name     VARCHAR(100),', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    email        VARCHAR(150) UNIQUE,', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    phone        VARCHAR(20) UNIQUE,', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    address      TEXT,', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    registration DATE         NOT NULL DEFAULT (CURRENT_DATE),', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    PRIMARY KEY (reader_id)', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: ');', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', children: [new TextRun({ text: '', size: 20 })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '-- 6. Выдача книг', size: 20, font: 'Courier New', italics: true })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: 'CREATE TABLE BORROWINGS (', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    borrowing_id INT         NOT NULL AUTO_INCREMENT,', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    reader_id    INT         NOT NULL,', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    book_id      INT         NOT NULL,', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    borrow_date  DATE        NOT NULL DEFAULT (CURRENT_DATE),', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    return_date  DATE,', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    status       VARCHAR(20) NOT NULL DEFAULT \'active\',', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    PRIMARY KEY (borrowing_id),', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    FOREIGN KEY (reader_id) REFERENCES READERS(reader_id),', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    FOREIGN KEY (book_id) REFERENCES BOOKS(book_id),', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: '    CHECK (status IN (\'active\',\'returned\',\'overdue\'))', size: 20, font: 'Courier New' })] }),
      new Paragraph({ style: 'Code', shading: { fill: 'f1f5f9', type: ShadingType.CLEAR }, children: [new TextRun({ text: ');', size: 20, font: 'Courier New' })] })
    ]
  }]
});

// Сохраняем документ
Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync('/home/z/my-project/public/LIBRARY_Technical_Documentation.docx', buffer);
  console.log('Word документ сохранён: /home/z/my-project/public/LIBRARY_Technical_Documentation.docx');
});
